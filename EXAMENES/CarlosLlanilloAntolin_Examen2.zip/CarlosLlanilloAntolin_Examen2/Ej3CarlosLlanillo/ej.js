while (true) {
  // Prguntamos un numero
  let num = parseInt(prompt(`Introduce un número entre 1 y 5`));
  // Y comprobamos si esta entre 1 y 5 para salir
  if (num >= 1 && num <= 5) break;
}

do {
  // Prguntamos un numero
  let num = parseInt(prompt(`Introduce un número entre 1 y 5`));
  // Y comprobamos si esta entre 1 y 5 para salir
  if (num >= 1 && num <= 5) break;
} while (true);
